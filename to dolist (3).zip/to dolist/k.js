const button = document.querySelector("button");
const container = document.getElementById("container");

button.addEventListener("click", addtask);

function addtask() {
    let input = document.getElementById("INPUT");
    let inputvalue = input.value.trim();

    if (inputvalue === "") {
        alert("add something");
        return;
    }

    let row = document.createElement("li");
    row.innerHTML = "🔵 " + inputvalue;
    row.style.listStyle = "none";
    // row.style.padding = "5px";
    // row.style.position="relative";
    // row.style.bottom="15px";

    // delete button
    let delBtn = document.createElement("button");
    delBtn.innerHTML = "❌";
    // delBtn.style.marginRight = "10px";

    delBtn.addEventListener("click", () => {
        row.remove();
        saveData();
    });

    // star button ⭐
    let starBtn = document.createElement("button");
    starBtn.innerHTML = "⭐";
    // starBtn.style.marginLeft = "10px";



    starBtn.addEventListener("click", () => {
        row.style.background = row.style.background === "yellow" ? "" : "yellow"; // toggle
    
    
    });

    row.appendChild(delBtn);
    row.appendChild(starBtn);
    container.appendChild(row);

    input.value = "";

    saveData();
}

function saveData() {
    localStorage.setItem("data", container.innerHTML);
}

function showTask() {
    let data = localStorage.getItem("data");

    if (data) {
        container.innerHTML = data;
    }

    // إعادة تفعيل الأزرار
    // let buttons = container.querySelectorAll("button");

    // buttons.forEach(btn => {
    //     btn.addEventListener("click", function () {
    //         btn.parentElement.remove();
    //         saveData();
    //     });
    // });
}

showTask();